#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Joy
from std_msgs.msg import String

class JoystickToCommand(Node):
    def __init__(self):
        super().__init__('joystick_to_command')
        self.publisher = self.create_publisher(String, '/puppy_motion_command', 10)
        self.subscription = self.create_subscription(Joy, '/joy', self.joy_callback, 10)

    def joy_callback(self, msg):
        command = String()
        if msg.buttons[0]:  # A button
            command.data = 'walk'
        elif msg.buttons[1]:  # B button
            command.data = 'turn_left'
        elif msg.buttons[2]:  # X button
            command.data = 'stand'
        else:
            return
        self.publisher.publish(command)
        self.get_logger().info(f'Published command: {command.data}')

def main():
    rclpy.init()
    node = JoystickToCommand()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
